; ========================================================
;  FrameX Installer Script (Inno Setup 6)
;  Developer: ZAKI  |  Instagram/TikTok: @zg22x
; ========================================================

#define MyAppName "FrameX"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "ZAKI"
#define MyAppURL "https://instagram.com/zg22x"
#define MyAppExeName "FrameX.exe"
#define MyAppDescription "Professional Screen Recorder"

[Setup]
AppId={{A7F3C2D1-8B4E-4F92-A1C6-3D7E9B2F5A84}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
LicenseFile=LICENSE.txt
OutputDir=output
OutputBaseFilename=FrameX_Setup_v{#MyAppVersion}
SetupIconFile=..\resources\icons\framex.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
WizardResizable=no
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64

; Custom wizard appearance
WizardImageFile=installer_banner.bmp
WizardSmallImageFile=installer_logo.bmp

; Uninstall icon
UninstallDisplayIcon={app}\{#MyAppExeName}
UninstallDisplayName={#MyAppName}

; Min Windows version: Windows 10
MinVersion=10.0.17763

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "arabic"; MessagesFile: "compiler:Languages\Arabic.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "quicklaunchicon"; Description: "{cm:CreateQuickLaunchIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked; OnlyBelowVersion: 6.1
Name: "startupicon"; Description: "Start FrameX automatically with Windows"; GroupDescription: "Startup Options:"; Flags: unchecked

[Files]
; Main executable
Source: "..\build\Release\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

; Qt Runtime DLLs
Source: "..\deploy\Qt6Core.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\Qt6Gui.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\Qt6Widgets.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\Qt6Multimedia.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\Qt6MultimediaWidgets.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\Qt6Network.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\Qt6Sql.dll"; DestDir: "{app}"; Flags: ignoreversion

; Visual C++ Runtime
Source: "..\deploy\vcruntime140.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\msvcp140.dll"; DestDir: "{app}"; Flags: ignoreversion

; Qt Plugins
Source: "..\deploy\platforms\qwindows.dll"; DestDir: "{app}\platforms"; Flags: ignoreversion
Source: "..\deploy\styles\qwindowsvistastyle.dll"; DestDir: "{app}\styles"; Flags: ignoreversion
Source: "..\deploy\imageformats\*"; DestDir: "{app}\imageformats"; Flags: ignoreversion recursesubdirs
Source: "..\deploy\multimedia\*"; DestDir: "{app}\multimedia"; Flags: ignoreversion recursesubdirs
Source: "..\deploy\sqldrivers\*"; DestDir: "{app}\sqldrivers"; Flags: ignoreversion recursesubdirs

; FFmpeg DLLs
Source: "..\deploy\avcodec-61.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\avformat-61.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\avutil-59.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\swscale-8.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\swresample-5.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\avdevice-61.dll"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\deploy\avfilter-10.dll"; DestDir: "{app}"; Flags: ignoreversion

; App resources
Source: "..\LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
Name: "{userappdata}\Microsoft\Internet Explorer\Quick Launch\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: quicklaunchicon

[Registry]
; Add to startup if selected
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "{#MyAppName}"; ValueData: """{app}\{#MyAppExeName}"""; Flags: uninsdeletevalue; Tasks: startupicon

; File associations
Root: HKCR; Subkey: ".framex"; ValueType: string; ValueName: ""; ValueData: "FrameXProject"; Flags: uninsdeletevalue
Root: HKCR; Subkey: "FrameXProject"; ValueType: string; ValueName: ""; ValueData: "FrameX Project File"; Flags: uninsdeletevalue
Root: HKCR; Subkey: "FrameXProject\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\{#MyAppExeName},0"; Flags: uninsdeletevalue
Root: HKCR; Subkey: "FrameXProject\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#MyAppExeName}"" ""%1"""; Flags: uninsdeletevalue

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{userappdata}\ZAKI\FrameX"
Type: dirifempty; Name: "{userappdata}\ZAKI"

[Code]
function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
begin
  Result := True;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    // Post-install steps if needed
  end;
end;
